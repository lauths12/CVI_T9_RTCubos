#include "rtweekend.h"
#include "camera.h"
#include "hittable.h"
#include "hittable_list.h"
#include "material.h"
#include "quad.h" 

int main() {
    hittable_list world;

    auto ground_material = make_shared<lambertian>(color(0.5, 0.5, 0.5));
    shared_ptr<hittable> ground_box = box(point3(-300, -0.01, -300), point3(300, 0, 300), ground_material);
    world.add(ground_box);

    for (int a = -11; a < 11; a++) {
        for (int b = -11; b < 11; b++) {
            auto choose_mat = random_double();
            point3 center(a + 0.9*random_double(), 0.2, b + 0.9*random_double());

            if ((center - point3(4, 0.2, 0)).length() > 0.9) {
                shared_ptr<material> box_material;

                if (choose_mat < 0.8) {
                    // diffuse
                    auto albedo = color::random() * color::random();
                    box_material = make_shared<lambertian>(albedo);
                } else if (choose_mat < 0.95) {
                    // metal
                    auto albedo = color::random(0.5, 1);
                    auto fuzz = random_double(0, 0.5);
                    box_material = make_shared<metal>(albedo, fuzz);
                } else {
                    // glass
                    box_material = make_shared<dielectric>(1.5);
                }

                point3 min_corner = center - vec3(0.2, 0.2, 0.2);
                point3 max_corner = center + vec3(0.2, 0.2, 0.2);
                shared_ptr<hittable> random_box = box(min_corner, max_corner, box_material);
                world.add(random_box);
            }
        }
    }

    auto material1 = make_shared<dielectric>(1.5);
    shared_ptr<hittable> box1 = box(point3(-0.5, 0.0, -0.5), point3(0.5, 1.0, 0.5), material1);
    world.add(box1);

    auto material2 = make_shared<lambertian>(color(0.4, 0.2, 0.1));
    shared_ptr<hittable> box2 = box(point3(-4.5, 0.0, -0.5), point3(-3.5, 1.0, 0.5), material2);
    world.add(box2);

    auto material3 = make_shared<metal>(color(0.7, 0.6, 0.5), 0.0);
    shared_ptr<hittable> box3 = box(point3(3.5, 0.0, -0.5), point3(4.5, 1.0, 0.5), material3);
    world.add(box3);

    camera cam;

    cam.aspect_ratio      = 16.0 / 9.0;
    cam.image_width       = 1200;
    cam.samples_per_pixel = 10;
    cam.max_depth         = 20;

    cam.vfov     = 20;
    cam.lookfrom = point3(13,2,3);
    cam.lookat   = point3(0,0,0);
    cam.vup      = vec3(0,1,0);

    cam.defocus_angle = 0.6;
    cam.focus_dist    = 10.0;

    cam.render(world);
}
